package com.Jtests;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.junit.Test;

import com.chess.pgn.PGNUtilities;
import com.chess.pgn.ParsePGNException;
import com.google.common.io.Resources;

public class TestPGNParser {

    @Test
    public void test1() throws IOException {
        doTest("com/Jtests/pgn/t1.pgn");
    }

    @Test
    public void test2() throws IOException {
        doTest("com/Jtests/pgn/t2.pgn");
    }

    @Test
    public void test3() throws IOException {
        doTest("com/Jtests/pgn/t3.pgn");
    }

    @Test
    public void test4() throws IOException {
        doTest("com/Jtests/pgn/t4.pgn");
    }

    @Test
    public void test5() throws IOException {
        doTest("com/Jtests/pgn/smallerTest.pgn");
    }

    @Test
    public void test6() throws IOException {
        doTest("com/Jtests/pgn/t6.pgn");
    }

    @Test
    public void test8() throws IOException {
        doTest("com/Jtests/pgn/t8.pgn");
    }

    @Test
    public void test9() throws IOException {
        doTest("com/Jtests/pgn/t9.pgn");
    }

    @Test
    public void testPawnPromotion() throws IOException {
        doTest("com/Jtests/pgn/queenPromotion.pgn");
    }

    @Test
    public void test10() throws IOException {
        doTest("com/Jtests/pgn/t10.pgn");
    }

    @Test
    public void testParens() throws ParsePGNException {

        final String gameText = "(+)-(-) (+)-(-) 1. e4 e6";
        final List<String> moves = PGNUtilities.processMoveText(gameText);
        System.out.println(moves.size());
        assert(moves.size() == 2);

    }


    private static void doTest(final String testFilePath) throws IOException {
        final URL url = Resources.getResource(testFilePath);
        final File testPGNFile = new File(url.getFile());
        PGNUtilities.persistPGNFile(testPGNFile);
    }
}
