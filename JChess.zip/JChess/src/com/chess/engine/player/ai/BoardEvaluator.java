package com.chess.engine.player.ai;

import com.chess.engine.board.Board;

public interface BoardEvaluator {

    //TODO : Er zijn meerdere bestanden in de AI map die ik ofwel niet begrijp, alleen bij tests gebruik of helemaal niet gebruik. Het meeste is al opgeruimd
    //MiniMax (hangt nog even af van de werking van de AI)


    int evaluate(Board board, int depth);
}
