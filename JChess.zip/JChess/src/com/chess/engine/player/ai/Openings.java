package com.chess.engine.player.ai;

import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;

public enum Openings {
    RUY_LOPEZ{
        @Override
        public Move[] initiate(Board chessBoard) {
            Move[] RUY_LOPEZ = new Move[5];
            /*RUY_LOPEZ[0] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("e2")),BoardUtils.INSTANCE.getCoordinateAtPosition("e4"));
            RUY_LOPEZ[1] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("e7")),BoardUtils.INSTANCE.getCoordinateAtPosition("e5"));
            RUY_LOPEZ[2] = new Move.MajorMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("g1")),BoardUtils.INSTANCE.getCoordinateAtPosition("f3"));
            RUY_LOPEZ[3] = new Move.MajorMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("b8")),BoardUtils.INSTANCE.getCoordinateAtPosition("c6"));
            RUY_LOPEZ[4] = new Move.MajorMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("f1")),BoardUtils.INSTANCE.getCoordinateAtPosition("b5"));*/
            return RUY_LOPEZ;
        }

        @Override
        public int length() {
            return 5;
        }
    },
    SICILIAN_DEFENSE{
        @Override
        public Move[] initiate(Board chessboard) {
            Move[] SICILIAN_DEFENSE = new Move[2];
            return SICILIAN_DEFENSE;
        }

        @Override
        public int length() {
            return 2;
        }
    },
    SCANDINAVIAN_OPENING{
        @Override
        public Move[] initiate(Board chessboard) {
            Move[] SCANDINAVIAN_OPENING = new Move[2];
            return SCANDINAVIAN_OPENING;
        }

        @Override
        public int length() {
            return 2;
        }
    };

    public abstract Move[] initiate(Board chessboard);
    public abstract int length();

    //https://dwheeler.com/chess-openings/

    /*Move[] RUY_LOPEZ = new Move[5];
    Move[] SICILIAN_DEFENSE = new Move[2];
    Move[] SCANDINAVIAN_OPENING = new Move[2];

    public Openings(){

    }

    public Move[] RuyLopez(Board chessBoard){
        RUY_LOPEZ[0] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("e2")),BoardUtils.INSTANCE.getCoordinateAtPosition("e4"));
        RUY_LOPEZ[1] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("e7")),BoardUtils.INSTANCE.getCoordinateAtPosition("e5"));
        RUY_LOPEZ[2] = new Move.MajorMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("g1")),BoardUtils.INSTANCE.getCoordinateAtPosition("f3"));
        RUY_LOPEZ[3] = new Move.MajorMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("b8")),BoardUtils.INSTANCE.getCoordinateAtPosition("c6"));
        RUY_LOPEZ[4] = new Move.MajorMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("f1")),BoardUtils.INSTANCE.getCoordinateAtPosition("b5"));

        return RUY_LOPEZ;
    }

    public Move[] SicilianDefense(Board chessBoard){
        SICILIAN_DEFENSE[0] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("e2")),BoardUtils.INSTANCE.getCoordinateAtPosition("e4"));
        SICILIAN_DEFENSE[1] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("c7")),BoardUtils.INSTANCE.getCoordinateAtPosition("c5"));
        return SICILIAN_DEFENSE;
    }

    public Move[] ScandinavianOpening(Board chessBoard){
        SCANDINAVIAN_OPENING[0] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("e2")),BoardUtils.INSTANCE.getCoordinateAtPosition("e4"));
        SCANDINAVIAN_OPENING[1] = new Move.PawnMove(chessBoard,chessBoard.getPiece(BoardUtils.INSTANCE.getCoordinateAtPosition("d7")),BoardUtils.INSTANCE.getCoordinateAtPosition("d5"));
        return SCANDINAVIAN_OPENING;
    }
*/

}
